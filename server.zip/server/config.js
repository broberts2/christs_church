module.exports = {
  port: process.env.PORT || 5000,
  contactFromEmail: "christschurch28@gmail.com",
  contactFromPassword: "Matthew28:19",
  token: {
    access_token:
      "ya29.GlvEBlY-zotq2cjkLhWRqS641T0m4mZM8jrO-TSy8bfhFxIuaMbFRDVI0pUATZhpEkNchyVYdIQpeg6oIfhDtQtHMZxF5Z1HtYjv6qWqPPCpfR0Y6ESDpSHfcrqW",
    refresh_token: "1/x7Z_kMZfQcRWY0fMPdFNMSs5tbXXzLS9wmZRFusdJh0",
    scope: "https://www.googleapis.com/auth/drive",
    token_type: "Bearer",
    expiry_date: 1551839493850
  }
};
