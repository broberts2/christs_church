module.exports = {
  installed: {
    client_id:
      "241855818759-mct9h4mge5518es9bcvg75rrsr39bt7o.apps.googleusercontent.com",
    project_id: "quickstart-1548966504919",
    auth_uri: "https://accounts.google.com/o/oauth2/auth",
    token_uri: "https://oauth2.googleapis.com/token",
    auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
    client_secret: "NN03JTcugmeDiyI58zjIKE-b",
    redirect_uris: ["urn:ietf:wg:oauth:2.0:oob", "http://localhost"]
  }
};
